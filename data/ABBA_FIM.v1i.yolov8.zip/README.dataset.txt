# ABBA_FIM > 2024-07-30 1:33pm
https://universe.roboflow.com/leo-jessat1999-gmail-com/abba_fim

Provided by a Roboflow user
License: CC BY 4.0

