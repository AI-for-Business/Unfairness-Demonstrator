# ABBA_FIM > 2024-08-09 3:27pm
https://universe.roboflow.com/abbafim/abba_fim

Provided by a Roboflow user
License: CC BY 4.0

