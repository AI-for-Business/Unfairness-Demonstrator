# ABBA_FIM > 2024-08-19 9:15am
https://universe.roboflow.com/abbafim/abba_fim

Provided by a Roboflow user
License: CC BY 4.0

